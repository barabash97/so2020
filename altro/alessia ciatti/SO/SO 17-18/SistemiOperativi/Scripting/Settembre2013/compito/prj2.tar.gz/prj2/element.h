#ifndef __ELEMENT__
#define __ELEMENT__
struct element
  {
  struct element* next;
  struct element* prev;
  double num; 
  };

#endif
