#include <stdlib.h>
#include <stdio.h>
#include "list.h"

void print_list(struct list* L)
{
   struct element* p;
   for (p=L->first; p!=NULL; p=p->next) 
     printf("%f\n", p->num);
}
