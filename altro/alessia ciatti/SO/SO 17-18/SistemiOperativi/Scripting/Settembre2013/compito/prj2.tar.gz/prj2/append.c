#include <stdlib.h>
#include "element.h"
#include "list.h"


/* aggiunge un elemento in coda alla lista */
void append(struct list* L, double n)
{
  struct element* p;
  p= (struct element*)malloc( sizeof(struct element) );
  p->num=n;
  p->next=NULL;
  p->prev=L->last;

  /*primo elemento della lista?*/
  if (L->first==NULL) 
    L->first=p;
  else 
    L->last->next=p;

  L->last=p;
}
