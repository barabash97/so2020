
#include "list.h"
void print_list(struct list* L);
