

#include "list.h"

void init_list(struct list*, int n);

