#ifndef __LIST__
#define __LIST__
#include "element.h"

struct list
  {
  struct element* first;
  struct element* last;
  };

#endif
