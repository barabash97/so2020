#include <stdlib.h>

#include "list.h"


struct list*  create_list()
{
   return (struct list*)malloc(sizeof(struct list*));
}


