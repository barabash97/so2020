
#include "append.h"
#include "list.h"
#include <math.h>
long int fib( long int f1 )
{
   long int f;	
   if ( f1==1 || f1==2 )
     f = 1;
   else
     f = fib(f1-1) + fib(f1-2);
   return f;
}

void init_list(struct list* L, int n)
{
   int i;
   for (i=1; i<=n; i++)
     {
     double x=pow(fib(i), log(i));
     append(L, x);
     }
}

