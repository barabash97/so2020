#include "list.h"
void append(struct list*, double n);

