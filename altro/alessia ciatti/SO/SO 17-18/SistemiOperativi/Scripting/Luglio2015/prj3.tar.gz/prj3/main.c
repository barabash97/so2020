#include<stdio.h> 
#include<stdlib.h> 

#include "list.h"
#include "create_list.h"
#include "init_list.h"
#include "print_list.h"

struct list* L;

int main(int argc, char** argv)
{
  int n;
  if (argc!=2)
     {
     fprintf(stderr, "uso: %s <limite>\n", argv[0]);
     exit(1);
     }
  n=atoi(argv[1]);
  L=create_list();
  init_list(L, n);
  print_list(L);
  return 0;
}
