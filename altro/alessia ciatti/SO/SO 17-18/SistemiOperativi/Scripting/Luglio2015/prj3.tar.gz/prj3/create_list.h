

#include "list.h"
#include "element.h"


struct list* create_list();

