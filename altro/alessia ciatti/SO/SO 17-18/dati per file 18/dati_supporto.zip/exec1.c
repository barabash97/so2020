#include	<stdio.h> /* standard I/O stream of C language */
#include	<sys/types.h> /* standard POSIX types */
#include	<unistd.h> /* miscellaneous symbolic constants and types */
#include	<stdlib.h>	 /* standard of C language for performing general functions */
#include	<sys/wait.h>

char	*env_init[] = { "USER=unknown", "PATH=/tmp", NULL };

int main(void) {
	pid_t	pid;

    if ( (pid = fork()) < 0){
        printf("Cannot fork!!\n");
        exit(1);
    }
	else if (pid == 0) {	/* specify pathname, specify environment */
		if (execle("./echoall",
                   "echoall", "myarg1",
                   "MY ARG2",
                   (char *) 0,
                   env_init) < 0){
            printf("Cannot execle!!\n");
            exit(1);
        }
			
	}
    if (waitpid(pid, NULL, 0) < 0){
        printf("Cannot waitpid!!\n");
        exit(1);
    }

    if ( (pid = fork()) < 0){
        printf("Cannot fork!!\n");
        exit(1);
    }
	else if (pid == 0) {	/* specify filename, inherit environment */
		if (execlp("./echoall",
				   "echoall",
                   "only 1 arg",
                   (char *) 0) < 0){
            printf("Cannot execlp!!\n");
            exit(1);
        }
			
	}
	exit(0);
}
