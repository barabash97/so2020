#include	<stdio.h> /* standard I/O stream of C language */
#include	<sys/types.h> /* standard POSIX types */
#include	<unistd.h> /* miscellaneous symbolic constants and types */
#include	<stdlib.h>	 /* standard of C language for performing general functions */

int		glob = 6;		/* external variable in initialized data */
char	buf[] = "fork1 write to stdout\n";

int main(void) {
	int		var;		/* automatic variable on the stack */
	pid_t	 pid;

	var = 88;
	
	/* STDOUT_FILENO is a file descriptor of LINUX system */
	
	if (write(STDOUT_FILENO, buf, sizeof(buf)) != sizeof(buf)) {
		printf("Cannot write!!\n");
        exit(1);
	}

	printf("before fork\n");	/* we don't flush stdout */

	if ( (pid = fork()) < 0) {
		printf("Cannot fork!!\n");
        exit(1);
	}

	else 
	  if (pid == 0) {		/* child */
		glob++;					/* modify variables */
		var++;
	    } 
	  else
		sleep(2);				/* parent */

	printf("pid = %d, glob = %d, var = %d\n", getpid(), glob, var);
	
	exit(0);
}
