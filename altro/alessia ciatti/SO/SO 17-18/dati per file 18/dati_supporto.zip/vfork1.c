#include	<stdio.h> /* standard I/O stream of C language */
#include	<sys/types.h> /* standard POSIX types */
#include	<unistd.h> /* miscellaneous symbolic constants and types */
#include	<stdlib.h>	 /* standard of C language for performing general functions */

int		glob = 6;		/* external variable in initialized data */

int main(void) {
	int		var = 88;		/* automatic variable on the stack */
	pid_t	 pid;

	
	printf("before vfork\n");	/* we don't flush stdio */

	if ( (pid = vfork()) < 0){
		printf("Cannot vfork!!\n");
        exit(1);
	}
	
	else 
	   if (pid == 0) {		/* child */
		  glob++;					/* modify parent's variables */
          var++;
		_exit(0);				/* child terminates */
	   }

	/* parent */
	printf("pid = %d, glob = %d, var = %d\n", getpid(), glob, var);
	exit(0);
}
