#include	<stdio.h>
#include	<sys/types.h>
#include	<unistd.h>
#include	<stdlib.h>

int main(void) {
	pid_t	pid;

    if ( (pid = fork()) < 0) {
        printf("Cannot fork!!\n");
        exit(1);
    }
	else
        if (pid == 0) {
            printf("output from child\n");
        }
        else {
            printf("output from parent\n");
        }
	exit(0);
}
