/* stampa_info.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main (int argc, char* argv[]) {
    
    if (argc < 1) {
        printf("USAGE: ./stampa_info <tipo_parentela>\n");
    }
    
    if (strcmp(argv[1], "nipote")==0) {
       printf("Sono il nipote del primo padre\n");
    }
    else {
        printf("Sono il figlio del secondo padre\n");
    }
    
   exit(0);    
}
