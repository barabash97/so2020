#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char stringa[20];
stringa name;

void get_name(stringa file) {
    int i, cont = 0;
    for (i = 0; file[i] != '.'; i++)
        name[i] = file[i];
}

int main (void) {
    
    stringa file = "file1.c";
    get_name(file);
    printf("Nome del file: %s\n",name);
    exit(0);
}