#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef char stringa[20];
stringa name;

char* get_name(stringa file) {
    int i, cont = 0;
    for (i = 0; file[i] != '.'; i++)
        name[i] = file[i];
    return name;
}

int main (int argc, char* argv[]) {
    
    int i;
    /* controllo argomenti */
    if (argc < 2) {
        printf("[USAGE]: ./compila_esegui file1.c ... filen.c\n");
        return 0;
    }
    int status;
    for (i=1; i < argc; i++){
        int pid = fork();
        if (pid > 0) { /* processo padre */
            printf("procedo con il file: %s\n",argv[i]);
            wait(&status);
        }
        else {
            if (pid == 0) { /* processo figlio */
                /* recupero nome sorgente ed eseguibile */
                pid = fork();
                if (pid > 0)  { /* processo figlio */
                    int terminated_pid = wait(&status);
                    /* verifica condizioni di errore */
                    if (WEXITSTATUS(status)==0){
                        execl(get_name(argv[i]),get_name(argv[i]),(char*)0);
                        perror("esecuzione");
                        exit(1);
                    }
                
                }
                else { /* processo nipote */
                    if (pid == 0) {
                        execl ("/usr/bin/gcc", "/usr/bin/gcc", argv[i], "-o", get_name(argv[i]), (char*)0);
                        perror("compilazione");
                        exit(1);
                    }
                }
            }
        }
    }
    return 0;
    
}