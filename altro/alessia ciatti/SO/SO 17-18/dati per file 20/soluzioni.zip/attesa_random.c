#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
    
    pid_t pid1, pid2, pid3, term1, term2;
    int stato1, stato2;
    
    // si richiama la funzione fork per creare il primo figlio
    
    pid1 = fork ();
    if ( pid1 == 0 ) {
        // quello che segue è il codice eseguito dal primo figlio
        printf ("[Primo figlio - PID: %d] Lancio il programma 'stampa_argv'\n", getpid());
        execl ("./stampa_argv", "stampa_argv", "Parametro_#1", "Parametro_#2", "Parametro_#3", NULL);
        exit ( -1 );
        } 
        
    // il padre procede subito senza aspettare la terminazione del figlio   
    // si chiama ancora la funzione fork per creare il secondo figlio
    
    pid2 = fork ();
    if ( pid2 == 0 )  {
        // quello che segue è il codice eseguito dal secondo figlio
        printf ("[Secondo figlio - PID: %d] Creo una altro figlio, il terzo\n", getpid());
        pid3 = fork ();
        if (pid3 == 0 ) {
             // quello che segue è il codice eseguito dal terzo figlio
             printf ("[Terzo figlio - PID: %d] Vado a dormire...\n", getpid());
             sleep (rand()%5);
             printf ("[Terzo figlio] Svegliato! Termino subito.\n");
             exit ( 2 );
        }
        exit (1);
    }
    
    // si attende la terminazione dei primi due figli, non si sa in quale ordine
    
    term1 = wait ( &stato1 );
    term2 = wait ( &stato2 );
    
    // probabilmente terminano i primi due figli, perchè il terzo dorme un po'...
    
    printf ("Ordine di terminazione dei primi due figli: 1: %d - 2: %d\n", term1, term2);
    exit ( 0 );
    
}
