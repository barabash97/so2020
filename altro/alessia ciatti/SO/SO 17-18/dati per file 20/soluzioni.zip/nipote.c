/* nipote.c */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
    
   int status;
    pid_t pid_f1, pid_f2, pid_n; 
    pid_f1 = fork (); // creazione primo figlio
    
    if (pid_f1 == 0) { // sono il primo figlio
      printf("Sono il processo figlio del primo padre\n");
      pid_n = fork ();
      if (pid_n == 0) { // sono il nipote
         execlp ("./stampa_info","stampa_info","nipote", (char *) 0);
         exit (0);
      }
      wait (&status); // il primo figlio attende il nipote
      exit (pid_n);
      }
      
      else { // sono il primo padre
        printf("Sono il primo processo padre\n");
        wait (&status); // il primo padre attende il primo figlio
    }
      
      
      pid_f2 = fork (); // il secondo padre genera un figlio
       if (pid_f2 == 0) { // sono il secondo figlio
        execlp ("./stampa_info","stampa_info","figlio", (char *) 0);
        exit (0);
    }
    else {
        printf("Sono il secondo processo padre\n");
        wait (&status); // il secondo padre attende il secondo figlio
    }
    
}
