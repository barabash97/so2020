/* stampa_argv.c */

#include <stdio.h>

int main ( int argc , char *argv[] ) {
    if ( argc == 4 ) {
       printf ( "Nome del programma: %s\n" , argv[0] );
       printf ( "Parametro n. 1: %s\n" , argv[1] );
       printf ( "Parametro n. 2: %s\n" , argv[2] );
       printf ( "Parametro n. 3: %s\n" , argv[3] );
       } 
    else {
       /* Errore: parametri di input errati */
       printf ( "\nUtilizzo: %s Par_1 Par_2 Par_3\n\n" , argv[0] );
    }
}