#include <stdio.h>
#include <stdlib.h>
#include <errno.h> //per la perror()
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> //per la WEXITSTATUS() macro

int main(void) {
    pid_t pid;
    int uscita;
    switch(pid=fork()) {
        case -1:
            perror("fork");  /* errore */
            exit(1);         /* il padre esce con errore 1 */
        case 0:
            printf(" CHILD: processo figlio !\n");
            printf(" CHILD: il mio PID : %d\n", getpid());
            printf(" CHILD: il PID di mio padre: %d\n", getppid());
            printf(" CHILD: scrivi il valore di uscita (< 100):\n ");
            scanf(" %d", &uscita);
            printf(" CHILD: termino !\n");
            exit(uscita);
            
        default:
            sleep(5); //serve per avere il tempo
            //di scrivere il valore di exit()
            printf("PARENT: processo padre !\n");
            printf("PARENT: il mio PID : %d\n", getpid());
            printf("PARENT: il PID di mio figlio : %d\n", pid);
            printf("PARENT: Attendo la fine del figlio ...\n");
            wait(&uscita);
            printf("PARENT: ecco lo stato di uscita del figlio :%d\n", WEXITSTATUS(uscita));
            printf("PARENT: termino !\n");
    }
    return 0;
}