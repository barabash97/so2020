
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void catch_int(int sig_num) {
    printf("\nDon't do that\n"); /* print the message */
    fflush(stdout);
}

int main (void) {
   
    /* set the INT (Ctrl-C) signal handler to 'catch_int' */
    signal(SIGINT, catch_int);
    for ( ;; )
        pause();
}
