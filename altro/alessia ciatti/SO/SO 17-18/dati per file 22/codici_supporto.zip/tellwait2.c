#include  <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include  "tellwait.c"

int main(void){
  pid_t pid;

  TELL_WAIT();

  if ( (pid = fork()) < 0)
    err_sys("fork error");
  else if (pid == 0) {
    WAIT_PARENT();   /* parent goes first getppid()*/
    printf("output from child\n");
  } else {
    printf("output from parent\n");
    TELL_CHILD(pid);
  }
  exit(0);
}
