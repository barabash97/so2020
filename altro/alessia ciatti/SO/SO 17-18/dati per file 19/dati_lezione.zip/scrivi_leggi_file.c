#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
    pid_t pid;
    int i;
    char c;
    // si apre il file in scrittura
    FILE *textFile = fopen ( "./test.txt" , "w+" );
    if ( textFile != NULL ) {
		// si richiama la funzione fork per creare un figlio
		pid = fork ();
		
		if (pid < 0) {
            perror("fork");
            exit(2);
        }
		
		if ( pid == 0 ) {
     		// quello che segue è il codice eseguito dal figlio
    		 // si attendono alcuni secondi per dare tempo al processo
    		 // padre di terminare la propria esecuzione
    		 
    		 printf ("[figlio] Attendo 4 secondi...\n");
    		 sleep ( 4 );
     		
     		// si stampa la posizione attuale del cursore sul file
     		// si noterà che è posizionato alla fine del file...
     		
     		printf ("\n[figlio] Posizione attuale puntatore file: %ld\n", ftell(textFile) );
     		
     		// si riporta all'inizio il cursore
     		
     		fseek(textFile, 0, SEEK_SET);
    		
    		 // si stampa il contenuto testuale del file, carattere
    		 // per carattere
     		
     		printf ("[figlio] Stampo contenuto del file di testo: ");
    		 
    		 c = fgetc ( textFile );
     		while ( ! feof ( textFile ) ) {
         		printf ("%c" , c);
        		 c = fgetc ( textFile );
    		 }
    		 printf ("\n");
    		 
    		 
    		 
    		 // si chiude il file aperto e si esce dal processo
    		 
    		 printf ("[figlio] Chiudo il file ed esco.\n");
    		 fclose ( textFile );
     		exit ( 0 );
     		
     		// si nota che, nonostante il processo padre abbia già
    		 // cancellato il file, il processo figlio è comunque in
    		 // grado di leggerne il contenuto!
		}
		else {
			// segue il codice eseguito dal processo padre
			// si inseriscono alcuni caratteri nel file di testo
			
			printf ("[padre] Inserimento stringa nel file\n");
  				
  			fprintf(textFile, "%s\n", "Sono il padre");
			
			// si stampa la posizione attuale del cursore sul file
			
			printf ("[padre] Posizione attuale puntatore file: %ld\n", ftell(textFile) );
			// si chiude il file aperto e lo si cancella dal filesystem 
			printf ("[padre] Chiudo il file e lo cancello\n");
			
			fclose ( textFile );
			remove ( "test.txt" );
		} // fine else padre
	} // fine else sul controllo del file
	else {
        printf ("Errore! Non è stato possibile aprire il file.\n");
    }
    
}
