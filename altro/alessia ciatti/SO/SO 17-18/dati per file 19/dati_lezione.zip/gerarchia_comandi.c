#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define DIM 20
typedef char stringa[80];
typedef stringa strvett[DIM];
int gestoresequenza(int N, strvett vett);
void get_stato(int S, int pid);

int main(void) {
    int pid,ncom, stato, i;
    strvett vstr;
    printf("quanti comandi? ");
    scanf("%d", &ncom);
    for(i=0; i<ncom; i++) {
        printf("\ndammi il prossimo comando(senza argomenti)");
        scanf("%s", vstr[i]);
        }
    gestoresequenza(ncom-1,vstr);
    pid=wait(&stato);
    get_stato(stato,pid);
    exit(0);
    }
    
int gestoresequenza(int N, strvett vett) { 
    int stato;
    int pid;
    pid=fork();
    
    if (pid < 0) {
        perror("fork");
        exit(2);
    }
    
    if (pid==0) /* figlio*/ {
        if (N==-1) /* processo foglia */ {
            printf("\nfoglia %d \n", getpid());
            exit(0);
        }
        else /*attivazione di un nuovo comando*/ {
 
            pid=gestoresequenza(N-1, vett);
            
           }
    } // fine else figlio
    else { /* padre */
        if (N != -1){
        printf("\nProcesso %d per comando %s", pid, vett[N]);
        pid=wait(&stato);
        get_stato(stato,pid);
        
        if (execlp(vett[N], vett[N], (char *)0) < 0) {
            perror("exec");
            exit(-1);
         }
        exit(0);
        }
    } // fine else padre
    
}

void get_stato(int S, int pid) {
    printf("\nterminato processo n.%d", pid);
    if (S==0)
        printf(" terminazione volontaria con stato %d\n", S);
    else 
        printf(" terminazione involontaria per segnale %d\n", S);
}