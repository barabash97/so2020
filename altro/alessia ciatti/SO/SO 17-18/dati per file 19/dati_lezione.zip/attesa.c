#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
    
    pid_t pid;
    int status;
    
    // si richiama la funzione fork per creare un figlio
    
    pid = fork ();
    
    if (pid < 0) {
        perror("fork");
        exit(2);
    }
    
    if ( pid == 0 ) {
        // quello che segue è il codice eseguito dal figlio
        // si stampano a STDOUT le informazioni richieste
        
        printf ("[figlio] Il mio PID è %d e quello del processo che mi ha invocato è %d\n" , getpid() , getppid() );
        
        // si produce un codice di ritorno
        
        exit ( 24 );
        }
    else {
        // segue il codice eseguito dal processo padre
        
        printf ("[padre] In attesa della terminazione del processo figlio...\n");
        
        // si attende che il processo figlio termini la computazione
        
        pid = wait ( &status );
        
        // OK: si sblocca il padre perchè il figlio ha terminato
        
        printf ("[padre] Il figlio, con PID %d, ha terminato il lavoro con il seguente codice di ritorno: %d.\n", pid , status/256 );
    }
    
}
