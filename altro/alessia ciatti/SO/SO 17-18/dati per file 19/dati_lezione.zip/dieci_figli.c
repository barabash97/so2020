/*
 * programma genera 10 processi figli successivamente ogni
 * figlio stampa il suo nome a distanza di un secondo l'uno dall'altro. * Poi i figli ritornano 100 + n°figlio e il pgm stampa
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define NUMP 10         /* Numero di figli da generare */

int main(void) {
    int i,pid;
    // Genera i 10 processi
    for(i=0;i<NUMP;i++){
        pid = fork();
        
        if (pid < 0) {
            perror("fork");
            exit(2);
        }
        
        if (pid==0) { // figlio
            sleep(1); // Ritardo iniziale
            printf("Figlio: %d\n",i+1); // Stampa messaggio del figlio
            sleep(1); // Ritardo finale
            exit(101+i); // Termina con codice di ritorno

        }
        else { // padre (il pid e' quello del figlio)
            printf("Ho generato il figlio %d con pid %d\n",i+1,pid);
        }
    } // fine del for
    // Attende che dieci processi terminino
    for(i=0;i<NUMP;i++){
        int status;
        wait(&status);              // Attende termine di un figlio (uno qualunque)
        printf("Terminato processo %d\n",WEXITSTATUS(status));
    }
}// fine del main