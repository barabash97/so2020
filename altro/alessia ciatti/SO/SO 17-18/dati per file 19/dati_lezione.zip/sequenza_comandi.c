#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define DIM 20
typedef char stringa[80];
typedef stringa strvett[DIM];
int gestoresequenza(int N, strvett vett);


int main(void) {
    int pid,ncom, stato, i;
    strvett vstr;
    printf("quanti comandi? ");
    scanf("%d", &ncom);
    for(i=0; i<ncom; i++) {
        printf("\ndammi il prossimo comando(senza argomenti)");
        scanf("%s", vstr[i]);
        }
    gestoresequenza(ncom,vstr);
    exit(0);
    }
    
int gestoresequenza(int N, strvett vett) { 
    int stato;
    int pid, i;
    for (i = 0; i < N; i++){
        printf("Comando %s con indice %d\n",vett[i],i);
        pid=fork();
        
        if (pid < 0) {
            perror("fork");
            exit(2);
        }
        
        if (pid == 0) { // figlio
            system(vett[i]);
            exit(0);
        }
        
        else { // padre
            pid = wait(&stato);
        }
        
    }
    
    
}