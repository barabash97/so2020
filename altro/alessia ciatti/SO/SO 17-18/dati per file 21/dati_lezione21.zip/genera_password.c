
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
   
    char password[20];
    char words[2];
    printf("dammi password:\n");
    scanf("%s",password);
    words[0]=password[0];
    words[1]=password[1];
    printf("password %s criptata in %s\n", password, crypt(password,words));

}
       

