
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void) {
   
   pid_t esito;
   int status;
   char comando[128];
   while(1) {
    printf("myshell# ");
    scanf("%s", comando); //lettura rudimentale: niente argomenti separati
    if ((esito=fork()) < 0)
        perror("fallimento fork");
    else
        if (esito == 0) {
            execlp(comando,comando,NULL); // NOTA: non gestisce argomenti
            perror("Errore esecuzione:");
            exit(0);
        }
        else{ // codice genitore
            while( wait(&status) != esito ); // aspetta completamento
        }
       // il processo genitore (shell) torna immediatamente a leggere un altro comando
   }
       
}
