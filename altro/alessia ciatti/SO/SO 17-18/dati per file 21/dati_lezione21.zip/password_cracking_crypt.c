#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define MAX_STRING 50

int main( int argc , char *argv[] ) {
        char passwordSalt[3],
        generatedPasswordToTest [MAX_STRING],
        dictionaryPasswordToTest [MAX_STRING],
        secredPass[MAX_STRING],
        initialChar;
        
        FILE *dictionaryFile;
        
        if ( argc == 4 ) {
            /* Ok, ci sono tutti i parametri necessari */
            /* si apre il file del dizionario */
            
            dictionaryFile = fopen ( argv[3] , "r" );
            if ( dictionaryFile != NULL ) {
                 /* si inizializzano alcune variabili */
                    strcpy ( secredPass, argv[1] );
                    initialChar = *argv[2];
                    passwordSalt[2] = '\000';
                    
                    /* lettura dell'intero file delle parole del dizionario */
                     while ( ! feof ( dictionaryFile ) )  {
                        /* lettura del file riga per riga */
                        fgets ( dictionaryPasswordToTest , MAX_STRING , dictionaryFile );
                         /* controllo se l'iniziale della parola è quella da gestire */
                        if ( dictionaryPasswordToTest[0] == initialChar ) {
                            /* si toglie il carattere di 'a capo' sovrascrivendolo con il
                            carattere 'terminatore di stringa' */
                                if (dictionaryPasswordToTest[strlen (dictionaryPasswordToTest)- 1] == '\n') {
                                    dictionaryPasswordToTest[strlen (dictionaryPasswordToTest)- 1] = '\000';
                                }
                           /* si crea il "salt" necessario per l'algoritmo di creazione
                            della password criptata e la si genera */
                            passwordSalt[0] = dictionaryPasswordToTest[0];
                            passwordSalt[1] = dictionaryPasswordToTest[1];
                            
                            strcpy ( generatedPasswordToTest , crypt (dictionaryPasswordToTest, passwordSalt) );
                            

                            /* si controlla se la password appena generata coincide con
                            quella passata in input */
                            
                            if (!strcmp ( secredPass, generatedPasswordToTest ) ) {
                                printf ("\n******************************************\n");
                                printf ("Password TROVATA!: '%s' (criptata = %s)\n", dictionaryPasswordToTest , generatedPasswordToTest );
                                printf ("******************************************\n");
                                fclose (dictionaryFile);
                                /* il codice di ritorno è il codice ASCII della lettera iniziale */
                                exit ( initialChar );
                            }
                        }
                    }
                    /* il controllo è terminato e non è stata trovata nessuna password che combaci */
                    printf ("\nLa password non è stata trovata con le parole che iniziano con la lettera '%c'\n" , initialChar);
                    fclose (dictionaryFile);
                    exit ( 1 );
                    }
                    else {
                        printf ("\nErrore nella lettura del file! Exit.\n");
                        exit(2);
                    }
        }
        else {
            /* Errore: parametri di input errati */
            printf ( "\nUtilizzo: %s password_criptata lettera_iniziale descrittore_file_dizionario\n\n" , argv[0] );
            exit(3);
        }
}
