#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MAX_CHARS 50
#define NUM_CHARS 52

int main (void) {
    
    pid_t pid[NUM_CHARS], term[NUM_CHARS];
    int exit_state[NUM_CHARS], n;
    
    char charList[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
    charToTry[2], cryptedPassword[MAX_CHARS], asciiFileHandler[MAX_CHARS],
    dictionaryFilename[] = "dictionary.txt";
    
    /* Inizializzazione di alcune variabili */
    n = 0;
    charToTry[1] = '\000';
    
    /* Si chiede all'utente di inserire la password in forma criptata.
   L'algoritmo utilizzato è il "crypt" di Unix */
    
    printf ("Inserire la password criptata: ");
    scanf ("%s", cryptedPassword);
    
    while (n < NUM_CHARS) {
        pid[n] = fork ();
        
        if ( pid[n] == 0 ) {
            
            printf ("\nFiglio #%d (con PID = %d) incaricato delle parole che iniziano per '%c'\n" , n, getpid() , charList[n]);
            charToTry[0] = charList[n];
            execl ("./password_cracking_crypt", "password_cracking_crypt", cryptedPassword, charToTry , dictionaryFilename, NULL);
            exit ( -1 ); 
        }
        else {
            // padre
            n++; 
            }
    }
    
    /* Si attende che tutti i processi figli creati portino a termine
   il compito assegnato; si utilizza la funzione “wait” e si memorizza
   il PID del processo terminato e il relativo codice di ritorno.
    */
    for (n = 0; n < NUM_CHARS; n++) {
        term [n] = wait (&exit_state [n]);
    }
    
    printf ("\nTutti i processi figli sono terminati!\n\n");
    for (n = 0; n < NUM_CHARS; n++) {
        if ((exit_state [n] / 256) <= 3 )
            printf ("PID = %d - Valore di ritorno = %d \n", term [n], exit_state [n] / 256);
        else
            printf ("Il processo con PID = %d ha trovato che la password inizia per '%c' \n", term [n], exit_state [n] / 256);
    }
    exit ( 0 );
        
}
